<?php 
if($_SERVER['REQUEST_METHOD']=="POST")
{
   if(isset($_POST['school-name']) && isset($_POST['class-name']) && isset($_POST['school-email']) && isset($_POST['school-email-pass']) ){
     	$school_name=$_POST['school-name'];
     	$class_name=$_POST['class-name'];
     	$school_email=$_POST['school-email'];
     	$email_pass=$_POST['school-email-pass'];
     	//echo  "student name"+$school_name+"class name"+$class_name+"school email"+$school_email+"email pass"+$email_pass;
       
   }
   	
}

 ?>
 <!DOCTYPE html>
 <html>
 <head>
 	<title>
 		SignUp
 	</title>
 	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
 	<script
    src="https://code.jquery.com/jquery-3.5.1.js"
    integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc="
    crossorigin="anonymous">
    </script>
    <link rel="stylesheet" type="text/css" href="index_Style.css">
 </head>
 <body>
 	<!--CREATE A SIGN-UP FORM-->
<center> <div id="signup-area">
 	<div id="sinup-form-title" style="font-size: 20px ; color: blue;" >SignUp Here </div>
 	<div id="SignUp-form-area">
 		<form id="signup-form" action="" method="post">
 			<div id="school-info">
 	     <label>School name</label><br>
         <input type="text" name="school-name" placeholder="school name..." id="school-nane" class="form-control"><br>
         <label>Class name</label><br>
         <input type="text" name="class-name" placeholder="class name..." class="form-control"><br>
         </div>	
         <div id="signup-info">
         	<label>Email</label><br>
         	<input type="text" name="school-email"class="form-control" ><br>
         	<label>Password</label><br>
         	<input type="password" name="school-email-pass"class="form-control"><br>
         </div>	
         <input type="submit" name="submit-button" value="submit" class="btn btn-success btn-lg">	
 		</form>
 	</div>	
 </div>

</center>
 </body>
 <script type="text/javascript">
  var signup=false;
	$("#signup-form").submit(function(event){
		if(!signup){
          event.preventDefault();
			$("#school-info").hide();
			$("#signup-info").show();
			signup=true;
		}
	         
	});
	
</script>
 </html>